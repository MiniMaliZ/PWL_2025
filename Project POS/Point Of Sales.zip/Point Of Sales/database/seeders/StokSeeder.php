<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StokSeeder extends Seeder
{
    public function run()
    {
        for ($i = 1; $i <= 10; $i++) {
            DB::table('t_stok')->insert([
                'stok_id' => $i,
                'barang_id' => $i,
                'user_id' => rand(1, 3), 
                'stok_tanggal' => now(),
                'stok_jumlah' => rand(10, 100),
            ]);
        }
    }
}